﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AForge.Imaging.Filters;
using AForge.Imaging.Formats;
using System.IO;

namespace Assignment1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        String imageName = String.Empty;

        private void buttonBrowseImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                imageName = ofd.FileName;
                textBox1.Text = ofd.FileName;
                pictureBoxConnectedRegion.ImageLocation = ofd.FileName;
                pictureBoxConnectedRegion.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        int compt = 1;

        private void buttonConnectedRegion_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(imageName))
            {
                Bitmap originalImage = (Bitmap)Bitmap.FromFile(imageName);
                Bitmap copyImage = (Bitmap)originalImage.Clone();
                Bitmap greyScale = ToGreyScale(copyImage);
                Bitmap normalize = NormalizeImage(greyScale);
                Bitmap conn = (Bitmap)normalize.Clone();

                ConnectedComponentsLabeling connectedComponents = new ConnectedComponentsLabeling();
                Bitmap newbit = connectedComponents.Apply(normalize);
                pictureBoxNewImage.Image = normalize;

                int count = connectedComponents.ObjectCount;

                richTextBox1.Text = count.ToString();
            }
        }

        private Bitmap checkNeigh(int j, int i, Bitmap bitmap)
        {
            Color current = bitmap.GetPixel(j, i);
            Color top , right;

            top = bitmap.GetPixel(j, i-1);
            right = bitmap.GetPixel(j + 1, i);;

            if (top.B != 0 || right.B != 0)
            {
                richTextBox1.Text = "\n updated \n";
                bitmap.SetPixel(j, i, Color.FromArgb((byte)1, (byte)1, (byte)compt));
            }
            else
            {
                compt++;
            }

            return bitmap;
        }

        private Bitmap connectedPixels(int j, int i, Bitmap bitmap, Color col)
        {
            if (bitmap.GetPixel(j, i).R == 1)
            {
                bitmap.SetPixel(i, j, Color.FromArgb((byte)1, (byte)compt, (byte)1));
                richTextBox1.Text += bitmap.GetPixel(j, i).R;  // Unhandled Exception Stack OverFlow
                connectedPixels(j, i + 1, bitmap, col);
                connectedPixels(j, i - 1, bitmap, col);
                connectedPixels(j + 1, i, bitmap, col);
                connectedPixels(j - 1, i, bitmap, col);
            }

            return bitmap;
        }

        private Bitmap NormalizeImage(Bitmap bitmap)
        {
            int i, j, px;
            Color color;
            for (i=0; i < bitmap.Width; i++)
            {
                for (j = 0; j < bitmap.Height; j++)
                {
                    color = bitmap.GetPixel(i, j);
                    if (color.R > 100)
                    {
                        px = 0;
                        bitmap.SetPixel(i, j, Color.FromArgb(px, px, px));
                    }
                    else
                    {
                        px = 1;
                        bitmap.SetPixel(i, j, Color.FromArgb(px, px, (byte)0));
                    }
                }
            }

            return bitmap;
        }

        private Bitmap ToGreyScale(Bitmap bitmap)
        {
            int grey, i, j;
            Color color;
            
            for (i = 0; i < bitmap.Width; i++)
            {
                for (j = 0; j < bitmap.Height; j++)
                {
                    color = bitmap.GetPixel(i,j);
                    grey = (int)((color.R + color.G + color.B) / 3);
                    try
                    {
                        bitmap.SetPixel(i, j, Color.FromArgb(grey, grey, grey));
                    }
                    catch { }
                }
            }

            return bitmap;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "JPeg Image|*.jpg";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                pictureBoxNewImage.Image.Save(sfd.FileName);
            }
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

    }
}
