﻿namespace Assignment1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBoxConnectedRegion = new System.Windows.Forms.PictureBox();
            this.buttonBrowseImage = new System.Windows.Forms.Button();
            this.buttonConnectedRegion = new System.Windows.Forms.Button();
            this.LabelResult = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.pictureBoxNewImage = new System.Windows.Forms.PictureBox();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxConnectedRegion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNewImage)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBoxConnectedRegion
            // 
            this.pictureBoxConnectedRegion.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxConnectedRegion.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBoxConnectedRegion.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxConnectedRegion.Location = new System.Drawing.Point(12, 12);
            this.pictureBoxConnectedRegion.Name = "pictureBoxConnectedRegion";
            this.pictureBoxConnectedRegion.Size = new System.Drawing.Size(412, 319);
            this.pictureBoxConnectedRegion.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxConnectedRegion.TabIndex = 0;
            this.pictureBoxConnectedRegion.TabStop = false;
            // 
            // buttonBrowseImage
            // 
            this.buttonBrowseImage.Location = new System.Drawing.Point(202, 352);
            this.buttonBrowseImage.Name = "buttonBrowseImage";
            this.buttonBrowseImage.Size = new System.Drawing.Size(75, 23);
            this.buttonBrowseImage.TabIndex = 1;
            this.buttonBrowseImage.Text = "Browse";
            this.buttonBrowseImage.UseVisualStyleBackColor = true;
            this.buttonBrowseImage.Click += new System.EventHandler(this.buttonBrowseImage_Click);
            // 
            // buttonConnectedRegion
            // 
            this.buttonConnectedRegion.Location = new System.Drawing.Point(439, 337);
            this.buttonConnectedRegion.Name = "buttonConnectedRegion";
            this.buttonConnectedRegion.Size = new System.Drawing.Size(125, 35);
            this.buttonConnectedRegion.TabIndex = 2;
            this.buttonConnectedRegion.Text = "Connected Regions";
            this.buttonConnectedRegion.UseVisualStyleBackColor = true;
            this.buttonConnectedRegion.Click += new System.EventHandler(this.buttonConnectedRegion_Click);
            // 
            // LabelResult
            // 
            this.LabelResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LabelResult.Location = new System.Drawing.Point(12, 252);
            this.LabelResult.Name = "LabelResult";
            this.LabelResult.Size = new System.Drawing.Size(265, 71);
            this.LabelResult.TabIndex = 3;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 352);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(184, 20);
            this.textBox1.TabIndex = 4;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(570, 337);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(125, 35);
            this.button1.TabIndex = 6;
            this.button1.Text = "Blob Detection";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(773, 12);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(162, 319);
            this.richTextBox1.TabIndex = 7;
            this.richTextBox1.Text = "";
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // pictureBoxNewImage
            // 
            this.pictureBoxNewImage.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxNewImage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBoxNewImage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxNewImage.Location = new System.Drawing.Point(439, 12);
            this.pictureBoxNewImage.Name = "pictureBoxNewImage";
            this.pictureBoxNewImage.Size = new System.Drawing.Size(328, 319);
            this.pictureBoxNewImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxNewImage.TabIndex = 8;
            this.pictureBoxNewImage.TabStop = false;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(701, 337);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(130, 35);
            this.button2.TabIndex = 9;
            this.button2.Text = "Save As...";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(947, 384);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.pictureBoxConnectedRegion);
            this.Controls.Add(this.pictureBoxNewImage);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.LabelResult);
            this.Controls.Add(this.buttonConnectedRegion);
            this.Controls.Add(this.buttonBrowseImage);
            this.Name = "Form1";
            this.Text = "Image Processing";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxConnectedRegion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNewImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBoxConnectedRegion;
        private System.Windows.Forms.Button buttonBrowseImage;
        private System.Windows.Forms.Button buttonConnectedRegion;
        private System.Windows.Forms.Label LabelResult;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.PictureBox pictureBoxNewImage;
        private System.Windows.Forms.Button button2;
    }
}

