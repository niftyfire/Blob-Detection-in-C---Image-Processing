﻿namespace Assignment1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBoxConnectedRegion = new System.Windows.Forms.PictureBox();
            this.buttonBrowseImage = new System.Windows.Forms.Button();
            this.buttonConnectedRegion = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.buttonAreas = new System.Windows.Forms.Button();
            this.buttonSaveAs = new System.Windows.Forms.Button();
            this.pictureBoxNew = new System.Windows.Forms.PictureBox();
            this.richTextBoxResult = new System.Windows.Forms.RichTextBox();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxConnectedRegion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNew)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBoxConnectedRegion
            // 
            this.pictureBoxConnectedRegion.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxConnectedRegion.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBoxConnectedRegion.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxConnectedRegion.Location = new System.Drawing.Point(12, 12);
            this.pictureBoxConnectedRegion.Name = "pictureBoxConnectedRegion";
            this.pictureBoxConnectedRegion.Size = new System.Drawing.Size(328, 299);
            this.pictureBoxConnectedRegion.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxConnectedRegion.TabIndex = 0;
            this.pictureBoxConnectedRegion.TabStop = false;
            // 
            // buttonBrowseImage
            // 
            this.buttonBrowseImage.Location = new System.Drawing.Point(258, 322);
            this.buttonBrowseImage.Name = "buttonBrowseImage";
            this.buttonBrowseImage.Size = new System.Drawing.Size(82, 23);
            this.buttonBrowseImage.TabIndex = 1;
            this.buttonBrowseImage.Text = "Browse";
            this.buttonBrowseImage.UseVisualStyleBackColor = true;
            this.buttonBrowseImage.Click += new System.EventHandler(this.buttonBrowseImage_Click);
            // 
            // buttonConnectedRegion
            // 
            this.buttonConnectedRegion.Enabled = false;
            this.buttonConnectedRegion.Location = new System.Drawing.Point(346, 345);
            this.buttonConnectedRegion.Name = "buttonConnectedRegion";
            this.buttonConnectedRegion.Size = new System.Drawing.Size(160, 35);
            this.buttonConnectedRegion.TabIndex = 2;
            this.buttonConnectedRegion.Text = "Connected Regions";
            this.buttonConnectedRegion.UseVisualStyleBackColor = true;
            this.buttonConnectedRegion.Click += new System.EventHandler(this.buttonConnectedRegion_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 322);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(240, 20);
            this.textBox1.TabIndex = 4;
            // 
            // buttonAreas
            // 
            this.buttonAreas.Enabled = false;
            this.buttonAreas.Location = new System.Drawing.Point(514, 345);
            this.buttonAreas.Name = "buttonAreas";
            this.buttonAreas.Size = new System.Drawing.Size(160, 35);
            this.buttonAreas.TabIndex = 6;
            this.buttonAreas.Text = "Size Detection";
            this.buttonAreas.UseVisualStyleBackColor = true;
            this.buttonAreas.Click += new System.EventHandler(this.buttonAreas_Click);
            // 
            // buttonSaveAs
            // 
            this.buttonSaveAs.Enabled = false;
            this.buttonSaveAs.Location = new System.Drawing.Point(788, 322);
            this.buttonSaveAs.Name = "buttonSaveAs";
            this.buttonSaveAs.Size = new System.Drawing.Size(160, 35);
            this.buttonSaveAs.TabIndex = 9;
            this.buttonSaveAs.Text = "Save As...";
            this.buttonSaveAs.UseVisualStyleBackColor = true;
            this.buttonSaveAs.Click += new System.EventHandler(this.button2_Click);
            // 
            // pictureBoxNew
            // 
            this.pictureBoxNew.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxNew.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxNew.Location = new System.Drawing.Point(346, 12);
            this.pictureBoxNew.Name = "pictureBoxNew";
            this.pictureBoxNew.Size = new System.Drawing.Size(328, 299);
            this.pictureBoxNew.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxNew.TabIndex = 10;
            this.pictureBoxNew.TabStop = false;
            // 
            // richTextBoxResult
            // 
            this.richTextBoxResult.BackColor = System.Drawing.Color.Black;
            this.richTextBoxResult.ForeColor = System.Drawing.Color.Silver;
            this.richTextBoxResult.Location = new System.Drawing.Point(681, 13);
            this.richTextBoxResult.Name = "richTextBoxResult";
            this.richTextBoxResult.ReadOnly = true;
            this.richTextBoxResult.Size = new System.Drawing.Size(267, 298);
            this.richTextBoxResult.TabIndex = 11;
            this.richTextBoxResult.Text = "";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(788, 363);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(160, 35);
            this.button1.TabIndex = 12;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(960, 411);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.richTextBoxResult);
            this.Controls.Add(this.buttonSaveAs);
            this.Controls.Add(this.pictureBoxConnectedRegion);
            this.Controls.Add(this.buttonAreas);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.buttonConnectedRegion);
            this.Controls.Add(this.buttonBrowseImage);
            this.Controls.Add(this.pictureBoxNew);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Image Processing -Connected Components";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxConnectedRegion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNew)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBoxConnectedRegion;
        private System.Windows.Forms.Button buttonBrowseImage;
        private System.Windows.Forms.Button buttonConnectedRegion;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button buttonAreas;
        private System.Windows.Forms.Button buttonSaveAs;
        private System.Windows.Forms.PictureBox pictureBoxNew;
        private System.Windows.Forms.RichTextBox richTextBoxResult;
        private System.Windows.Forms.Button button1;
    }
}

