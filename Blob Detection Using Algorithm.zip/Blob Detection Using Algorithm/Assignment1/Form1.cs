﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AForge.Imaging.Filters;
using AForge.Imaging.Formats;
using System.IO;
using System.Collections;

namespace Assignment1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        String imageName = String.Empty;
        List<int> labels = new List<int>();
        float average = 0;
        int big = 0, small = 0;
        int[] areas;

        private void buttonBrowseImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                imageName = ofd.FileName;
                textBox1.Text = ofd.FileName;
                pictureBoxConnectedRegion.ImageLocation = ofd.FileName;
                pictureBoxConnectedRegion.SizeMode = PictureBoxSizeMode.StretchImage;
                buttonConnectedRegion.Enabled = true;
            }
        }

        private void buttonConnectedRegion_Click(object sender, EventArgs e)
        {
            labels.Clear();
            average = 0;
            big = 0;
            small = 0;
            areas = null;
            ConnectedComponents();
        }

        private void ConnectedComponents()
        {
            if (!String.IsNullOrEmpty(imageName))
            {
                String str = String.Empty;
                Bitmap originalImage = (Bitmap)Bitmap.FromFile(imageName);
                Bitmap nonIndexed = originalImage.Clone(new Rectangle(0, 0, originalImage.Width, originalImage.Height), System.Drawing.Imaging.PixelFormat.Format32bppArgb);  // if image is indexed image onvert it to non indexed image
                Bitmap normalize = NormalizeImage(nonIndexed);

                Color c;
                int label = 1;
                int neighbourlabel = 0;
                int[,] copy = new int[normalize.Height, normalize.Width];
                labels.Add(0);

                // Phase 1
                 #region Phase 1

                for (int i = 0; i < normalize.Height; i++)
                {
                    for (int j = 0; j < normalize.Width; j++)
                    {
                        c = normalize.GetPixel(j, i);

                        if (c.R == 1)
                        {
                            neighbourlabel = CheckNeighbours(i, j, copy);

                            if (neighbourlabel == 0)
                            {
                                copy[i, j] = label;         // new label
                                labels.Add(label);
                                label++;                    // label++;
                            }
                            else
                            {
                                copy[i, j] = neighbourlabel;    // Neighbour Label
                            }
                            byte newR = (byte)copy[i, j];
                            if (newR > 255) newR = 255;
                            byte newG = (byte)(copy[i, j] + 30);
                            if (newG > 255) newG = 255;
                            byte newB = (byte)(copy[i, j] + 50);
                            if (newB > 255) newB = 255;

                            normalize.SetPixel(j, i, Color.FromArgb(newR, newG, newB));
                        }
                        //str += copy[i, j] + "   ";
                    }
                    //str += "\n\n";
                }
                #endregion 


                // Phase 2
                #region Phase 2
                
                Dictionary<int, List<int>> dict = new Dictionary<int, List<int>>();
                List<int> unique = labels.Distinct().ToList();
                List<int> temp = new List<int>();
                areas = new int[unique.Max()*2];
                
                int connectedComponents = 0;
                unique.Remove(0);

                connectedComponents = unique.Count;

                foreach (int key in unique)
                {
                    List<int> values = new List<int>();

                    for (int i = 1; i < labels.Count; i++)
                    {
                        if (labels[key] == labels[i] && labels[key] != i)
                            values.Add(i);
                    }

                    dict.Add(key, values);
                }

                for (int i = 0; i < normalize.Height; i++)
                {
                    for (int j = 0; j < normalize.Width; j++)
                    {
                        if (copy[i, j] > 0)
                        {
                            foreach (KeyValuePair<int, List<int>> adj in dict)
                            {
                                temp = adj.Value;
                                if (temp.Contains(copy[i, j]))
                                {
                                    copy[i, j] = adj.Key;
                                }
                            }
                        }
                    }    
                }

                for (int i = 0; i < normalize.Height; i++)
                {
                    for (int j = 0; j < normalize.Width; j++)
                    {
                        if (copy[i, j] != 0)
                        {
                            areas[copy[i, j]]++;
                        }
                    }
                    
                }

                for (int i = 0; i < areas.Length; i++)
                {
                    if (areas[i] != 0)
                        average += areas[i];
                }

                average /= connectedComponents;

                for (int i = 0; i < areas.Length; i++)
                {
                    if (areas[i] > 0)
                    {
                        if (areas[i] > average)
                            big++;
                        else
                            small++;
                    }
                }

                richTextBoxResult.Text = "Total Connected Components are " + connectedComponents + "\n\n";                


                pictureBoxNew.Image = normalize;

                #endregion

                buttonAreas.Enabled = true;
                buttonSaveAs.Enabled = true;
                buttonConnectedRegion.Enabled = false;
            }
        }

        private void SizeDetection()
        {
            int s = 1;

            richTextBoxResult.Text += "\nBig Components: " + big;
            richTextBoxResult.Text += "\nSmall Components: " + small;
            richTextBoxResult.Text += "\nAverage Size: " + average + " Pixels";
            richTextBoxResult.Text += "\n\nBig Components with Area";

            for (int i = 0; i < areas.Length; i++)
            {
                if (areas[i] > 0)
                {
                    if (areas[i] > average)
                    {
                        richTextBoxResult.Text += "\nConnected Component: " + s + ",  Area: " + areas[i] + " Pixels";
                        s++;
                    }
                }
            }

            richTextBoxResult.Text += "\n\nSmall Components with Area";
            s = 1;

            for (int i = 0; i < areas.Length; i++)
            {
                if (areas[i] > 0)
                {
                    if (areas[i] < average)
                    {
                        richTextBoxResult.Text += "\nConnected Component: " + s + ",  Area: " + areas[i] + " Pixels";
                        s++;
                    }
                }
            }

            buttonAreas.Enabled = false;
        }

        private int CheckNeighbours(int i, int j, int[ , ] copy)
        {
            if (i == 0)
            {
                if (j == 0)
                {
                    return 0;   
                }
                else
                {
                    return copy[ i, j-1];
                }
            }
            else
            {
                List<int> list = new List<int>();
                List<int> templist = new List<int>();
                int min = 0;

                if (j == 0)
                {
                    if (copy[i - 1, j] != 0)
                        list.Add(copy[i - 1, j]);

                    if (copy[i - 1, j + 1] != 0)
                        list.Add(copy[i - 1, j + 1]);

                    // returning  0
                    if (copy[i - 1, j] == 0 && copy[i - 1, j + 1] == 0) return 0;

                    min = list.Min();
                    list.Remove(min);
                    list = list.Distinct().ToList();

                    if (list.Count > 1)
                    {
                        foreach (int item in list)
                        {
                            labels[item] = labels[min];
                        }
                    }
                    return min;
                }
                else if (j == copy.GetLength(1)-1)
                {
                    if (copy[i - 1, j - 1] != 0)
                        list.Add(copy[i - 1, j - 1]);                        // N1
                    if (copy[i - 1, j] != 0) 
                        list.Add(copy[i - 1, j]);                            // N2
                    if (copy[i, j - 1] != 0) 
                        list.Add(copy[i, j - 1]);                            // N4

                    // returning  0
                    if (copy[i - 1, j - 1] == 0 && copy[i - 1, j] == 0 && copy[i, j - 1] == 0) return 0;

                    min = list.Min();
                    list.Remove(min);
                    list = list.Distinct().ToList();

                    if (list.Count > 1)
                    {
                        foreach (int item in list)
                        {
                            labels[item] = labels[min];
                        }
                    }
                    return min;
                }
                else
                {
                    if (copy[i - 1, j - 1] != 0) 
                        list.Add(copy[i - 1, j - 1]);     // N1

                    if (copy[i - 1, j] != 0) 
                        list.Add(copy[i - 1, j]);         // N2

                    if (copy[i - 1, j + 1] != 0) 
                        list.Add(copy[i - 1, j + 1]);     // N3

                    if (copy[i, j - 1] != 0) 
                        list.Add(copy[i, j - 1]);         // N4


                    // returning  0
                    if (copy[i - 1, j - 1] == 0 && copy[i - 1, j] == 0 && copy[i, j - 1] == 0 && copy[i - 1, j + 1] == 0) return 0;

                    min = list.Min();
                    list.Remove(min);
                    list = list.Distinct().ToList();

                    if (list.Count > 1)
                    {
                        foreach (int item in list)
                        {
                            labels[item] = labels[min];
                        }
                    }
                    return min;
                }
            }
        }

        private Bitmap NormalizeImage(Bitmap bitmap)
        {
            int i, j, px;
            Color color;
            for (i=0; i < bitmap.Width; i++)
            {
                for (j = 0; j < bitmap.Height; j++)
                {
                    color = bitmap.GetPixel(i, j);
                    if (((int)(color.R + color.B + color.G ) /3) > 128)
                    {
                        px = 0;
                        bitmap.SetPixel(i, j, Color.FromArgb(px, px, px));
                    }
                    else
                    {
                        px = 1;
                        bitmap.SetPixel(i, j, Color.FromArgb(px, px, px));
                    }
                }
            }

            return bitmap;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "JPeg Image|*.jpg";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                pictureBoxNew.Image.Save(sfd.FileName);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonAreas_Click(object sender, EventArgs e)
        {
            SizeDetection();
        }
    }
}
